import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.util.Util;
import net.imglib2.type.*;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;

/**
 *  Compute the gradient at each pixel location in the image in N dimensions,
 *  leaving out border pixels
 */
public class ImgLib2_Gradient1 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		Img<RealType> img = ImageJFunctions.wrapReal( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}

		// process wrapped image with ImgLib2
		process( img );
	}

	public <T extends RealType<T>> void process( Img<T> img )
	{
		// compute the gradient on the image
		Img<T> gradient = gradient( img );

		// show the new Img that contains the gradient
		ImageJFunctions.show( gradient );
	}

	public <T extends RealType<T>> Img<T> gradient( Img< T > img )
	{
		// create a new ImgLib2 image of same type & dimensions, for that
		// get the current factory of the image and use it to create a new
		// image. The img can serve as dimensionality, its firstElement() 
		// as instance required to instantiate the new image.
				
		// create a localizing cursor on the GradientImg, it will iterate all pixels
		// and is able to efficiently return its position at each pixel, at each
		// pixel we will compute the gradient

		// instantiate a RandomAccess in the original image, use it to 
		// compute the gradient locally at each pixel location

		// iterate over all pixels
		while ( cursor.hasNext() )
		{
			// move the cursor to the next pixel
			
			// test if we are able to compute the gradient

			// compute gradient in each dimension, use a double
			// to sum up the quadratic difference in each dimension

			// for each dimension d
			
			{
				// set the randomaccess to the location of the cursor
			
				// move one pixel back in dimension d

				// get the value 
				
				// move twice forward in dimension d, i.e.
				// one pixel above the location of the cursor
				
				// get the value
				
				// add the square of the magnitude of the gradient
			}

			// the square root of all quadratic sums yields
			// the magnitude of the gradient at this location,
			// set the pixel value of the gradient image
		}

		return ...;
	}
}