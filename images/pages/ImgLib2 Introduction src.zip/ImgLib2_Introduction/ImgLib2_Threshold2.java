import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.planar.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.type.*;
import net.imglib2.type.logic.BitType;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;

/**
 * Perform a threshold on an image (32-bit only),
 * display the result in a new ImgLib2 Img.
 */
public class ImgLib2_Threshold2 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		Img<FloatType> img = ImageJFunctions.wrapFloat( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}

		// process wrapped image with ImgLib2
		process( img );
	}

	public void process( Img<FloatType> img )
	{
		// define threshold
		float threshold = 100;

		// compute the threshold on the image in-place
		// (overwrite each pixel with the threshold value)
		Img<FloatType> thresholdImg = threshold( img, 100 );

		// show the new Img that contains the threshold
		ImageJFunctions.show( thresholdImg );
	}

    	public Img<FloatType> threshold( Img< FloatType > img, float threshold )
	{
		// create a new ImgLib2 image of same type & dimensions, for that
		// get the current factory of the image and use it to create a new
		// image. The img can serve as dimensionality, its firstElement() 
		// as instance required to instantiate the new image.
		ImgFactory<FloatType> imgFactory = ...
		Img<FloatType> thresholdImg = ...
		
		// now extend your previous example to write the result into the
		// just created image instead of overwriting the input

		/**
		// create a cursor on the Img, it will iterate all pixels
		Cursor<FloatType> cursor = img.cursor();

		// iterate over all pixels
		while ( cursor.hasNext() )
		{
			// get the value of the next pixel
			FloatType pixelValue = cursor.next();

			// set the 0 or 255 depending on the value
			if ( pixelValue.get() > threshold )
				pixelValue.set( 255 );
			else
				pixelValue.set( 0 );
			
		}
		*/
		return ...;
	}
}