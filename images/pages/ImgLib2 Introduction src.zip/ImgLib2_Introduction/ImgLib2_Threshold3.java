import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.planar.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.type.*;
import net.imglib2.type.logic.BitType;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;

/**
 * Perform a threshold on an image (all RealTypes),
 * display the result in a new ImgLib2 Img.
 */
public class ImgLib2_Threshold3 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		// change it here to wrap it into a RealType Img
		Img<FloatType> img = ImageJFunctions.wrapFloat( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}

		// process wrapped image with ImgLib2
		process( img );
	}

	// change the definition from FloatType to T by defining T as generic
	// parameter <T extends RealType<T>> between "public" and "void"
	// also change all occurences of FloatType to T in this method
	public void process( Img<FloatType> img )
	{
		// define threshold
		float threshold = 100;

		// compute the threshold on the image in-place
		// (overwrite each pixel with the threshold value)
		Img<FloatType> thresholdImg = threshold( img, 100 );

		// show the new Img that contains the threshold
		ImageJFunctions.show( thresholdImg );
	}

	// change the definition from FloatType to T by defining T as generic
	// parameter <T extends RealType<T>> between "public" and "void"
	// also change all occurences of FloatType to T in this method
    	public Img<FloatType> threshold( Img< FloatType > img, float threshold )
	{
		// create a new ImgLib2 image of same type & dimensions
		ImgFactory<FloatType> imgFactory = img.factory();
		Img<FloatType> thresholdImg = imgFactory.create( img, img.firstElement() );

		// create a cursor on the Img and the destination, it will iterate all pixels
		Cursor<FloatType> cursor = img.cursor();
		Cursor<FloatType> cursorThresholdImg = thresholdImg.cursor();
		
		// iterate over all pixels
		while ( cursor.hasNext() )
		{
			// get the value of the next pixel in the input
			FloatType pixelValue = cursor.next();
			
			// get the value of the next pixel in the output
			FloatType thresholdImgValue = cursorThresholdImg.next();

			// set the 0 or 255 depending on the value
			// change get() and set() which are specialized 
			// method for FloatType to setReal() and getRealFloat()
			if ( pixelValue.get() > threshold )
				thresholdImgValue.set( 1 );
			else
				thresholdImgValue.set( 0 );	
		}

		return thresholdImg;
	}
}