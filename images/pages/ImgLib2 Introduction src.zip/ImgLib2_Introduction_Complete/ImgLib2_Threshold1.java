import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.type.*;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;

/**
 * Perform a threshold on an img (32-bit only)
 */
public class ImgLib2_Threshold1 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		Img<FloatType> img = ImageJFunctions.wrapFloat( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}

		// process wrapped image with ImgLib2
		process( img );

		// re-draw the ImgPlus instance
		// works because we actually changed the img itself
		imp.updateAndDraw();
	}

	public void process( Img<FloatType> img )
	{
		// define threshold
		float threshold = 100;

		// compute the threshold on the image in-place
		// (overwrite each pixel with the threshold value)
		threshold( img, 100 );
	}

	public void threshold( Img< FloatType > img, float threshold )
	{
		// create a cursor on the Img, it will iterate all pixels
		Cursor<FloatType> cursor = img.cursor();

		// iterate over all pixels
		while ( cursor.hasNext() )
		{
			// get the value of the next pixel
			FloatType pixelValue = cursor.next();

			// set the 0 or 255 depending on the value
			if ( pixelValue.get() > threshold )
				pixelValue.set( 255 );
			else
				pixelValue.set( 0 );
			
		}
	}
}