beadsExampleData.tif
To track beads in this file th following settings should be used:
Intensity Offset = 100
EMCCD gain  = 300
Electrons per A/D count = 12.17
